# CustomModelData registry for Aethra resource pack

| ID | relic_type | Material | Texture |
|----|------------|----------|---------|
| 1001 | blood_shard | red_dye | blood_shard.png |
| 1002 | ancient_shard | netherite_scrap | ancient_shard.png |
| 1003 | special_netherite | netherite_block | — |
| 1004 | special_crying_obsidian | crying_obsidian | — |
| 1005 | hardened_titan | netherite_ingot | — |
| 1006 | hades_gold | gold_ingot | — |
| 2001 | hades_blade | netherite_sword | hades_blade.png |
| 2002 | ares_sword | netherite_sword | ares_sword.png |
| 2003 | titan_sword | netherite_sword | titan_sword.png |
| 2004 | freedom_blade | netherite_sword | freedom_blade.png |
| 3001 | poseidon_trident | trident | — |
| 3002 | zeus_trident | trident | — |
| 4001 | aegis_shield | shield | — |

## Adding a new texture

1. Drop PNG into `rp/assets/bounty/textures/item/`
2. Create model in `rp/assets/bounty/models/item/<name>.json`
3. Add override to the vanilla item model in `rp/assets/minecraft/models/item/`
4. Assign the ID in `CustomModelData.java` and call `CustomModelData.apply()` in `RelicManager`
5. Run `rp/build.bat`
