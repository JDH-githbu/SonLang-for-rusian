@echo off
setlocal
set ROOT=%~dp0
set OUT=%ROOT%AethraRP.zip

if exist "%OUT%" del /f /q "%OUT%"

powershell -NoProfile -Command ^
  "Compress-Archive -Path '%ROOT%*' -DestinationPath '%OUT%' -Force"

echo Built %OUT%

copy /Y "%OUT%" "..\server\plugins\BountyPlugin\AethraRP.zip" >nul 2>&1
copy /Y "%OUT%" "..\bounty\src\main\resources\AethraRP.zip" >nul 2>&1

echo Copied to server and plugin resources.
pause
